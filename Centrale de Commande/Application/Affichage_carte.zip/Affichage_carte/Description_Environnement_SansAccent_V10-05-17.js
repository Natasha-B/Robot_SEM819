 {
	"unite":"cm",
	"terrain_evolution": [
	   {"point" : { "x": 200 , "y" : 0 } } ,
	   {"point" : { "x": 200 , "y" : 100 } },
	   {"point" : { "x": 350 , "y" : 100 } },
	   {"point" : { "x": 350 , "y" : 200 } },
	   {"point" : { "x": 450 , "y" : 200 } },
	   {"point" : { "x": 450 , "y" : 300 } },
	   {"point" : { "x": -50 , "y" : 300 } },
       {"point" : { "x": -50 , "y" : 0   } }	   
	],
   "obstacles" : [
       { "type" : "polygone",
	     "coordonnees": [
		  {"point" : { "x": 50, "y" : 50} },
	      {"point" : { "x": 100, "y" : 50} },
	      {"point" : { "x": 100, "y" : 100} },
	      {"point" : { "x": 50, "y" : 100} }
		  ]
		},
		{ "type" : "polygone",
	     "coordonnees": [
		  {"point" : { "x": 50, "y" : 150} },
	      {"point" : { "x": 100, "y" : 150} },
	      {"point" : { "x": 100, "y" : 250} },
	      {"point" : { "x": 50, "y" : 250} }
		  ]
		},
		{ "type" : "polygone",
	     "coordonnees": [
		  {"point" : { "x": 100, "y" : 200} },
	      {"point" : { "x": 200, "y" : 200} },
	      {"point" : { "x": 200, "y" : 250} },
	      {"point" : { "x": 100, "y" : 250} }
		  ]
		},
		{ "type" : "cercle",
	     "coordonnees": [
		 {"centre" : { "x": 275, "y" : 225}} ,
		{"rayon" : 25}
		 ] 
		},
		{ "type" : "polygone",
	     "coordonnees": [
		  {"point" : { "x": 150, "y" : 50} },
	      {"point" : { "x": 250, "y" : 50} },
	      {"point" : { "x": 250, "y" : 100} },
	      {"point" : { "x": 200, "y" : 150} },
		  {"point" : { "x": 150, "y" : 100} }
		  ]
		}
		],
	"contour_cible": [
	   {"point" : { "x": -100 , "y" : -50   } } ,
	   {"point" : { "x": 250 , "y" : -50 } },
	   {"point" : { "x": 250 , "y" : 50 } },
	   {"point" : { "x": 400 , "y" : 50 } },
	   {"point" : { "x": 400 , "y" : 150 } },
	   {"point" : { "x": 500 , "y" : 150 } },
	   {"point" : { "x": 500 , "y" : 350 } },
       {"point" : { "x": -100 , "y" : 350   } }	   
	],
	"balise" : [
	 {"centre" : { "x" : 300, "y" : 150 } },
	 {"centre" : { "x" : 400, "y" : 250 } }
],
	"cible"	: {"centre" :{ "x": 430, "y" : 150}, "hauteur": 150 }

	
 }		
		

