# -*- coding: utf-8 -*-
"""
Éditeur de Spyder

Ceci est un script temporaire.
"""
import numpy as np
import json
import matplotlib.pyplot as plt
from heapq import *
import os.path

#ouverture et stockage des données des fichiers json
f_envir = 'Description_Environnement_SansAccent_V10-05-17.js'


with open(f_envir) as json_data_envir:
    data_dict_envir = json.load(json_data_envir) 


"""

	"Balise" : [
	 {"centre" : { "x" : 300, "y" : 150 } },
	 {"centre" : { "x" : 400, "y" : 250 } },
"""

""" Déroulement scénario
- se mettre à la position de départ
- calculer nombre n etapes
- i = 1
- while i<n
    - calculer la position des obstacles à identifier avant i
    - calcul parcours optimal jusqu'à étape i apres avoir identifié les balises-obstacles
- aller à la position tir-cible
- donner coordonnées pour tir ?
- aller à l'arrivée
"""


#création de la matrice représentant le terrain
#on met des 0 sur les cases dispo et des 1 pour les cases non dispo
taille_robot = 1  #robot = 45cm²
terrain_data_dict = data_dict_envir.get("terrain_evolution")  #dictionaire contenant les infos du terrain
coord_terrain = [] 
coord_terrain_x = []
coord_terrain_y = []
size_terrain_dict = len(terrain_data_dict)
for i in range(size_terrain_dict):
    coord_terrain.append(terrain_data_dict[i].get("point"))
for j in range(size_terrain_dict):
    coord_terrain_x.append(int(coord_terrain[j].get("x")/taille_robot)) #coordonnées en x des sommets du terrain
    coord_terrain_y.append(int(coord_terrain[j].get("y")/taille_robot)) #coordonnées en y des sommets du terrain

        
""" Création de listes liées pour coord x et y"""        
dict_x_sorted0 = {} #on crée un dictionnaire pour trier les valeurs de terrain_cord_x
list_y_sorted = [(0,0) for i in range(size_terrain_dict)]#on crée un ditionnaire pour trier les valeurs de terrain_coord_y selon l'ordre précédent
for i in range(size_terrain_dict):
    dict_x_sorted0[i] = coord_terrain_x[i]   
    

    
"""Création de la modélisation du terrain en grille"""    

min_x = min(coord_terrain_x)
max_x = max(coord_terrain_x)
min_y = min(coord_terrain_y)
max_y = max(coord_terrain_y)

coord_terrain_x.append(coord_terrain_x[0])
coord_terrain_y.append(coord_terrain_y[0])

     
  
plt.figure(1)

cible_data_dict = data_dict_envir.get("cible")  #dictionaire contenant les infos du terrain
coord_cible = [] 
coord_cible_x = []
coord_cible_y = []
size_cible_dict = len(cible_data_dict)-1
#for i in range(size_cible_dict):
coord_cible.append(cible_data_dict.get("centre"))
for j in range(size_cible_dict):
    coord_cible_x.append(int(coord_cible[j].get("x")/taille_robot)) #coordonnées en x des sommets du terrain
    coord_cible_y.append(int(coord_cible[j].get("y")/taille_robot)) #coordonnées en y des sommets du terrain

theta1 = np.linspace(0, 2*np.pi, 16)
r1=20;
x1 = np.cos(theta1)*r1+coord_cible_x[0]
y1 = np.sin(theta1)*r1+coord_cible_y[0]

theta2 = np.linspace(0, 2*np.pi, 8)
r2=10;
x2 = np.cos(theta2)*r2+coord_cible_x[0]
y2 = np.sin(theta2)*r2+coord_cible_y[0]

for i in range(len(x1)):
    coord_cible_x.append(x1[i])
    coord_cible_y.append(y1[i])

for i in range(len(x2)):
    coord_cible_x.append(x2[i])
    coord_cible_y.append(y2[i])


balise_data_dict = data_dict_envir.get("balise")  #dictionaire contenant les infos du terrain
coord_balise = [] 
coord_balise_x = []
coord_balise_y = []
#size_cible_dict = len(cible_data_dict)-1
#for i in range(size_cible_dict):
for i in range(len(balise_data_dict)):
    coord_balise.append(balise_data_dict[i].get("centre"))

for j in range(len(coord_balise)):
    coord_balise_x.append(int(coord_balise[j].get("x")/taille_robot)) #coordonnées en x des sommets du terrain
    coord_balise_y.append(int(coord_balise[j].get("y")/taille_robot)) #coordonnées en y des sommets du terrain
    plt.scatter(coord_balise_x[j],coord_balise_y[j],label = "balise n°%i"%i)

#for i in range(len(coord_terrain_x)-1):
#    t=[]
#    t.append(coord_terrain_x[i])
#    t.append(coord_terrain_x[i+1])
#    if (t[1]-t[0]>0):
#        ax.fill_between(t,coord_terrain_y[i+1], facecolor='red')
axes = plt.gca()
axes.set_xlim(min_x-50, max_x+250)
axes.set_ylim(min_y-50, max_y+50)
plt.plot(coord_terrain_x,coord_terrain_y, color= 'blue')
g1=plt.scatter(coord_cible_x,coord_cible_y, color = 'red')
plt.legend(loc='lower right')



#simulation des obstacles sur le terrain
def object_on_map(obj,value,marge,taille_robot):
    #simule un objet obj sur le terrain grâce à la liste des coordonnées de ses sommets
    #puis remplit son interieur de la valeur value
    if marge<0:
        print("Erreur ! Choisissez une marge nulle ou positive")
        return
    if taille_robot<0:
        print("Erreur ! Le robot ne peut avoir une taille négative ! ")
        return
    coord_obj = []
    coord_obj_x = []
    coord_obj_y = []
    list_sommet_ob_i = obj.get('coordonnees')

    if obstacle_i_dict.get('type') == "cercle": #si l'obstacle est de forme circulaire
        #coordonées du centre du cercle 
        centre_coord_x = ((list_sommet_ob_i[0].get('centre')).get("x"))/taille_robot
        centre_coord_y = ((list_sommet_ob_i[0].get('centre')).get("y"))/taille_robot
        r = (list_sommet_ob_i[1].get('rayon'))/ taille_robot  #rayon du cercle 
        
        theta = np.linspace(0, 2*np.pi, 40)
        x = np.cos(theta)*r+centre_coord_x
        y = np.sin(theta)*r+centre_coord_y
        plt.plot(x, y, color = 'grey')
    else: # si l'obstacle n'est pas circulaire
    
        size_obj_dict = len(list_sommet_ob_i)
        for i in range(size_obj_dict):
            coord_obj.append(list_sommet_ob_i[i].get("point"))
        for j in range(size_obj_dict):
            coord_obj_x.append((coord_obj[j].get("x"))/taille_robot) #coordonnées en x des sommets du terrain
            coord_obj_y.append((coord_obj[j].get("y"))/taille_robot) #coordonnées en y des sommets du terrain
        """ Création de listes liées pour coord x et y""" 
        coord_obj_x.append(coord_obj_x[0])
        coord_obj_y.append(coord_obj_y[0])
        plt.plot(coord_obj_x,coord_obj_y, color = 'grey')
    return
            


obstacle_data_dict = data_dict_envir.get("obstacles")
n_obstacles = len(obstacle_data_dict)


marge = 0
value = 1 # valeur sur la map représentant les obstacles
for i in range (n_obstacles):
    obstacle_i_dict = obstacle_data_dict[i]
    object_on_map(obstacle_i_dict,value,marge,taille_robot)
    #plt.figure(i+3)
    #plt.imshow(terrain_numpy2)

plt.show()
    
plt.savefig('Map.png')

while(1):
    if os.path.exists('test.txt'):
        plt.clf()
        f=open('test.txt')
        plt.figure(1)
        plt.plot(coord_terrain_x,coord_terrain_y, color= 'blue')
        g1=plt.scatter(coord_cible_x,coord_cible_y, color = 'red')
        for j in range(len(coord_balise)):
            n_test=f.readline()
            plt.scatter(coord_balise_x[j],coord_balise_y[j],label = "%s"%n_test)
        for i in range (n_obstacles):
            obstacle_i_dict = obstacle_data_dict[i]
            object_on_map(obstacle_i_dict,value,marge,taille_robot)
        f.close()
        plt.legend(loc='lower right')
        plt.savefig('Map.png')
        os.remove('test.txt')
        
        
    





